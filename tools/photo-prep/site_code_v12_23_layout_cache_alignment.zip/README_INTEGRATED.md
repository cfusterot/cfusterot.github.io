# /archive/ v9

## Sidebar
`science/`, `visual_archive/` and `blog/` start closed for a first-time visitor.
After that, their state is remembered in localStorage and survives navigation.
The tree is hidden for the few milliseconds while the state is restored, preventing the close/open flash.

`source` is present in the blog folder on every integrated page, including `derives.html`.

## Visual Archive switching
Inside `visual_archive.html`, clicking `escitalopram/`, `photo/` or `video/` no longer reloads the HTML page.
The URL changes with `history.pushState` and the mural is rebuilt in place.
This removes the odd page transition/flicker.

## Cutouts and automatic folder reading
A static GitHub Pages page cannot ask the server to list the contents of `img/visual_archive/cutouts/`.
Instead, `Publicar_Imagenes_Web.command` now automatically generates:

`archive_media_manifest.js`

after processing the media.

The manifest catalogs every published photograph, video and cutout.
`visual_archive.html` and the local editor load this manifest and automatically add files that are not already present in the old explicit source list.

Therefore the workflow for a new cutout is now simply:

1. Put the transparent PNG in `img_originales/visual_archive/cutouts/`.
2. Run `Publicar_Imagenes_Web.command`.
3. It creates/updates `img/visual_archive/cutouts/...`.
4. It regenerates `archive_media_manifest.js`.
5. Reload the Visual Archive/editor.

No manual HTML entry is required.

Cutouts are tagged as `data-kind="cutout"` automatically, use `object-fit: contain`, keep alpha transparency, and do not receive CSS clip shapes.


## v10 — easy summary selection
The local editor adds `[ clear wall ]` and `[ library ]`.

Workflow:
1. Open `visual_archive_editor.html`.
2. Click `[ arrange ]`.
3. Click `[ clear wall ]`.
4. Open `[ library ]`.
5. Click thumbnails to add/remove only the pieces wanted in the summary.
6. Filter the library by photo, video, cutout, or escitalopram.
7. Arrange/resize selected pieces and save/export as usual.

`[ clear wall ]` only clears the current composition. It never deletes source files or the media catalogue.


## v10.2 — library additions fixed
Items added from `[ library ]` now use the same `enableDragging()` and four-corner `enableResizing()` logic as the initial wall.
New items are also placed with the existing collision-aware packing function instead of a simple fixed cascade, preventing late additions from overlapping manually moved pieces.


## v10.3 — durable summary layout + independent catalogue views

### Saving the arrangement permanently
The local editor now downloads a real file:

`visual_archive_layout.js`

with `[ download layout ]`.

Put that file in the repository root next to `visual_archive.html`.

That file contains:
- which images are in the summary,
- position,
- size,
- z-index,
- shape,
- silhouette state,
- removed items.

This is the file to keep forever. Future HTML updates can replace `visual_archive.html` and `visual_archive_editor.html` without losing the arrangement, as long as `visual_archive_layout.js` is kept.

`[ save ]` still stores a quick working copy in localStorage.
`[ load layout ]` can restore a previously downloaded `.js` or `.json` layout file.

### Public Visual Archive
- `/visual_archive.html` uses `visual_archive_layout.js` when present.
- If no durable layout has been exported yet, it temporarily shows all media.

### Photo / Video / Escitalopram
These views are now independent of the summary layout:
- `?view=photo` always shows ALL published photography.
- `?view=video` always shows ALL published video.
- `?view=escitalopram` always shows ALL published collage/Escitalopram media.

They ignore the summary's removed list and positions, and each view is freshly packed from the top of the page.


## v10.4 — saved arrangement included
`visual_archive_layout.js` already contains the imported arrangement from the previous editor.
Do not replace this file in future HTML-only updates unless you intentionally export a newer arrangement.


## v10.5 — critical layout loader fix
The previous package had a malformed `<script src="archive_media_manifest.js">` tag in `visual_archive.html`.
Because the navigation code was nested inside that external-script element, the browser ignored that inline code and `visual_archive_layout.js` was never loaded on the public page.

This version explicitly loads:
1. `archive_media_manifest.js`
2. `visual_archive_layout.js`
3. the inline page scripts

The imported saved arrangement is already present in `visual_archive_layout.js`.


## v10.6 — robust saved-layout loading
This package now includes:
- the populated `visual_archive_layout.js`,
- a populated fallback `archive_media_manifest.js`,
- an embedded emergency copy of the saved layout inside the Visual Archive HTML.

The public page can reconstruct the curated wall from the saved layout even if the generated manifest is missing or stale.
The external `visual_archive_layout.js` remains the canonical file for future edits.


## v10.7 — editor loading fixed
The public Visual Archive was already using the durable layout, but the local editor could initialize before the manifest/layout restoration sequence completed.
The editor now explicitly:
1. syncs the media manifest,
2. builds the wall,
3. restores the saved durable layout.

If an old empty localStorage entry exists, it falls back to `visual_archive_layout.js`.
A small top-right status shows `layout: X / wall: Y` for quick verification.


## v10.8 — actual editor blank-page bug fixed
The editor had a JavaScript syntax error inside the new `[ download layout ]` handler:
a multiline string was written as a normal quoted JavaScript string.
Because that syntax error was in the editor's main script block, the whole block failed before `buildWall()` could run, which produced `layout: 43 / wall: 0`.

The string is now correctly escaped and every inline JavaScript block in `visual_archive_editor.html` has been syntax-checked with Node.


## v10.9 — complete catalogue views fixed
The previous fallback manifest accidentally represented only part of the media catalogue.
This version reconstructs the catalogue from BOTH parts of the saved layout:

- selected summary items: 43
- items removed only from the summary: 103
- complete known catalogue: 146

`removed` now means exactly what it should mean: excluded from the curated Visual Archive summary, but still available in `photo`, `video`, and `escitalopram/collage`.

Subview rules:
- `?view=photo` = every image under `/photography/`
- `?view=video` = every video in the catalogue
- `?view=escitalopram` = every item under `/collage/`

Each subview is automatically repacked from the top and ignores the curated summary coordinates.


## v12 — local editing everywhere + playful public collage

- Sidebar background matches the page background.
- Sidebar title is `/archive/ index`.
- Local Visual Archive editor has independent editable views for:
  main Visual Archive, photo, video, collage.
- Each local section has its own localStorage key and layout download.
- Public collage view has a visitor `[ rearrange ]` mode with drag-and-drop and reset.
- Collage auto-layout uses a more silhouette-heavy shape palette.
- Source no longer jumps upward / snaps rotation on hover.
- Source is locally editable: drag, resize, front, save, reset, download.
- `source_layout.js` is the durable public Source arrangement.


## v12.1 — Visual Archive editor repaired
The v12 package accidentally removed the editor's main JavaScript block while adding per-section customization, causing `layout: 43 / wall: 0`.
This version restores the last known-good editor code and adds section customization without removing its core functions.

Local editable sections:
- visual archive
- photo
- video
- collage

The main view still restores the durable 43-item saved layout; subviews use independent localStorage keys.


## v12.2 — stable separation of catalogue vs curated layout

This package deliberately keeps two independent sources of truth:

- `archive_media_manifest.js` = COMPLETE media catalogue (146 known items)
- `visual_archive_layout.js` = curated main Visual Archive (43 positioned items)

Public subviews never use the curated summary as their catalogue:
- photo: 113 known photography items
- video: 4 known videos
- collage: 20 known collage items

The local editor keeps its full editor code and saved main layout while allowing section-specific local arrangements.

IMPORTANT for future updates:
Do not rebuild `archive_media_manifest.js` from the curated layout.
Do not rebuild `visual_archive_layout.js` from the full catalogue.
They solve different problems and must remain separate.


## v12.3 — editor subviews now use the full catalogue

The remaining loop was caused by an old editor-only in-place filter:
the editor first restored the curated 43-item wall and then `photo`,
`video`, or `collage` merely hid/showed items inside those 43.

That code is now removed.

In the local editor:
- main Visual Archive -> restores the curated durable layout
- photo -> reloads editor with `?view=photo` and builds from the COMPLETE manifest
- video -> reloads editor with `?view=video` and builds from the COMPLETE manifest
- collage -> reloads editor with `?view=escitalopram` and builds from the COMPLETE manifest

The public page and local editor therefore now use the same catalogue rules,
while only the main view uses the curated summary layout.


## v12.4 — explicit section filters
- `photo`: all images under `/photography/` except `/photography/derives/`
- `video`: only videos under `/super8/`
- derives images/videos remain in the complete catalogue so they can still be used in the curated Visual Archive and the future blog/derivés section
- the same rules are applied in both public and local editor views


## v12.5 — sidebar background corrected
The left archive/folder menu no longer uses its own gray value.
Its background is now forced to `transparent`, so it shows exactly the same
page background underneath and cannot appear darker than the main content.


## v12.6 — Source redesign
- Removed the botanical flower silhouette from Source. It was explicitly inserted as `img/source/flower_cutout.png`.
- Source no longer uses citation cards as the primary visual language.
- Images appear as free objects; concepts appear as lightweight text nodes.
- Clicking an image/concept opens a small contextual popover with title, description and optional external link.
- Local Source editor adds:
  `[ add image ]`, `[ add concept ]`, `[ remove ]`, `[ front ]`, `[ arrange ]`, `[ save ]`, `[ reset ]`, `[ download layout ]`.
- Added items are part of the serialized Source layout.
- Local save now writes to both localStorage and `window.name`, making same-tab refresh persistence more robust for `file://` pages.
- Dragging/resizing auto-saves silently; `[ save ]` gives a visible `saved ✓` confirmation.
- `source_layout.js` remains the durable layout file for publication.
- Default objects are more spatially mixed rather than grouped in a row of cards.


## v12.7 — Source editor controls aligned with Visual Archive
- Source now uses a single `[ arrange ]` button in the bottom-right, like the Visual Archive editor.
- Clicking it opens the full editing bar along the bottom.
- `[ done ]` closes editing and returns to the single arrange button.
- Control font, size, border, padding and background are matched to the existing local editor style.
- The editing bar now sits horizontally at the bottom instead of appearing as a low cluster.
- Arrange mode wiring was simplified so the toggle reliably enters/exits edit mode.


## v12.8 — Source controls placement actually fixed
The previous Source package had the correct control markup and JavaScript, but the final CSS rules for those controls had been accidentally removed. As a result the controls stayed in normal document flow at the bottom of the page.

This version adds a final explicit CSS override matching the Visual Archive editor:
- `[ arrange ]` fixed bottom-right at `right:22px; bottom:20px`
- editing toolbar fixed bottom-left at `left:20px; bottom:18px`
- same borderless buttons, Courier Prime, size, padding, translucent paper background, and spacing


## v12.9 — Source library + editable descriptions

Local Source workflow:
1. Put images in `img_originales/source/`.
2. Run the publisher.
3. It processes them to `img/source/` and generates `source_media_manifest.js`.
4. Open Source locally → `[ arrange ]` → `[ library ]`.
5. Click any thumbnail to add it to the page.
6. The metadata editor opens immediately so title, description, and optional URL can be entered.
7. Double-click any existing item while arranging, or use `[ edit info ]`, to edit its metadata later.

Images remain freely resizable using the resize handle while in arrange mode.
Their size, position, title, description, URL and z-index are all serialized into the Source layout.


## v12.10 — Source resize handles fixed
- Selected Source items now always show a visible resize handle at the bottom-right.
- The handle uses `!important` positioning/display rules so older CSS cannot hide it.
- Selecting an item explicitly ensures the handle exists.
- Images resize through their wrapper, with the image filling the wrapper width.


## v12.11 — Source library manifest fixed
The missing Source images were not a Source HTML problem: the publisher being used processed files into `img/source/`, but did not regenerate `source_media_manifest.js`. The library can only show files listed in that manifest because a static webpage cannot enumerate a directory.

Use `Publicar_Imagenes_Web_v14.command`. It now generates BOTH:
- `archive_media_manifest.js`
- `source_media_manifest.js`

The Source `[ refresh ]` button now reloads the page so it actually reads the freshly generated manifest instead of merely redrawing the old in-memory list.


## v12.12 — Source no automatic rotation
All Source images and concepts now start at `rotate(0deg)`.
New items added from the library also start perfectly straight.
Rotation is no longer randomized automatically.


## v12.13 — diary
Added `blog/diary` to the sidebar and a new `diary.html`.

The page is intentionally simple and paste-friendly:
- text can be pasted directly into `<section class="diary-post">`
- images live in `img/diary/`
- there is no card/grid UI; entries read as a continuous personal journal
- a short HTML example is embedded as a comment inside `diary.html`


## v12.15 — public page now applies local editor layouts
The public `visual_archive.html` had the correct localStorage key after v12.14,
but `buildWall()` never actually called `restoreSavedLayout()`.

Fixed:
- every public view applies its saved local editor layout after building the wall
- storage key is calculated from the CURRENT `?view=` URL, so in-page navigation
  between main/photo/video/escitalopram reads the correct saved layout too
- editor and public page therefore share:
  `visualArchiveManualLayout_v5_main`
  `visualArchiveManualLayout_v5_photo`
  `visualArchiveManualLayout_v5_video`
  `visualArchiveManualLayout_v5_escitalopram`
