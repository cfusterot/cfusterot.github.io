/* Complete catalogue reconstructed from the saved selection + removed list.
   IMPORTANT: 'removed' means removed only from the curated summary, NOT from photo/video/collage views.
   Running Publicar_Imagenes_Web.command may regenerate this from the actual media folders. */
window.ARCHIVE_MEDIA = [
  {
    "src": "img/visual_archive/photography/natur/R1-05190-0021.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-07608-0009.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-08955-0014.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/super8/besito.mp4",
    "type": "video",
    "kind": "",
    "project": "video"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-05460-027A.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-06387-0030.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-08944-0020.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-09835-0001.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-05000-035A.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-05054-0009.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04732-0011.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-07608-0030.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-08045-0013.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-02283-0029.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-02283-014A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04013-0012.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04726-0016.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05002-008A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05002-024A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05002-027A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05460-013A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05460-022A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05462-019A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-06387-0004.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-08944-0015.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-01880-0027.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-04726-0026.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-04874-0020.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-04874-0026.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-05053-0036.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/collage/13.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/c5_16.jpg",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/c5_5.jpg",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/cutouts/1.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/cutouts/2.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/cutouts/4.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/cutouts/5.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/cutouts/6.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/cutouts/7.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/cutouts/8.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/cutouts/9.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/photography/walkthisway/R1-04013-0007.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/super8/flores.mp4",
    "type": "video",
    "kind": "",
    "project": "video"
  },
  {
    "src": "img/visual_archive/collage/1.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/2.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/3.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/4.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/5.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/6.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/8.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-05002-034A.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-05190-0004.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-05190-0009.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-05461-002A.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-05461-004A.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-05779-0004.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-06387-0001.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-07608-0023.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-07608-0024.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-07608-0025.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-07608-0032.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-08944-0025.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/photography/natur/R1-08958-009A.jpg",
    "type": "img",
    "kind": "",
    "project": "natur"
  },
  {
    "src": "img/visual_archive/super8/plumitas.mp4",
    "type": "video",
    "kind": "",
    "project": "video"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-04275-0001.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-04601-017A.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-04601-018A.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-04601-021A.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-04629-0000.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-04629-0024.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-05002-005A.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-05460-024A.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/casitos/R1-06387-0000.jpg",
    "type": "img",
    "kind": "",
    "project": "casitos"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-04275-0022.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-04539-0014.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-04726-0014.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-04874-0008.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-05460-006A.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-05460-008A.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/selfie/R1-05461-005A.jpg",
    "type": "img",
    "kind": "",
    "project": "selfie"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04275-0025.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04415-023A.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04415-024A.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04539-0010.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04601-035A.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04629-0003.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04629-0007.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04726-0028.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-04874-0005.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-05190-0015.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/uncertainty/R1-07624-011A.jpg",
    "type": "img",
    "kind": "",
    "project": "uncertainty"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-01762-029A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-02283-0030.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04013-0010.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04275-0029.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04415-002A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04601-010A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04601-025A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04601-029A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04601-031A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04601-036A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04726-0003.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-04726-0008.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05002-007A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05002-021A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05002-026A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05460-005A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05460-016A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05460-034A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-05460-035A.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-06387-0007.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-06387-0010.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-07608-0019.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-08944-0004.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-08944-0014.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/berlin/R1-08944-0017.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-04726-0024.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-04874-0012.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-04874-0023.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-04874-0024.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-05053-0004.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-05053-0005.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-05053-0027.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-05053-0028.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/photography/walkthisway/spain/R1-05053-0037.jpg",
    "type": "img",
    "kind": "",
    "project": "walkthisway"
  },
  {
    "src": "img/visual_archive/collage/10.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/11.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/12.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/14.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/15.jpg",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/7-cutout.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/7.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/9.png",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/c7_10.jpg",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/collage/c7_8.jpg",
    "type": "img",
    "kind": "",
    "project": "escitalopram"
  },
  {
    "src": "img/visual_archive/cutouts/3.png",
    "type": "img",
    "kind": "cutout",
    "project": ""
  },
  {
    "src": "img/visual_archive/photography/derives/1A2950C0-8FDA-4C61-923C-A82D6E3EAAA6.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1A48B6DD-8C37-4A84-8A98-51D3EE52BE2C.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1A600455-9811-48B1-9F52-C883E4828BF9.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1A904AE4-F387-4C18-8CD8-4CFCD3BC4C4E.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1B0161B8-5933-4804-9DA9-5567E71E2B98.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1B2827BC-C290-4BB3-B2F4-FAD4F554026A.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1B2827BC-C290-4BB3-B2F4-FAD4F554026A_3.mp4",
    "type": "video",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1B3F909A-B76C-4767-A8E3-9333CF581B94.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1B6EA93D-C692-4C9B-9412-C5F6AD05A854.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  },
  {
    "src": "img/visual_archive/photography/derives/1BA01F62-7DE3-4A32-9ACF-DA8DCD63D650.jpeg",
    "type": "img",
    "kind": "",
    "project": "derives"
  }
];
